import { useState, useEffect, useRef } from 'react'
import { useLocation } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { getAssignedBot } from '../lib/botHelper'
import { useAuth } from '../lib/AuthContext'
import { useDataCache } from '../lib/DataCache'

const FILTERS = ['All', 'Pending', 'Follow Ups', 'Escalated', 'Resolved', 'Test']
const FOLLOW_UP_HOURS = 21
const STAGES = ['HOOK / ENTRY','GOAL','DIAGNOSTIC','INSIGHT','PRIORITY','DECISION','INVITE','SCHEDULE','BOOKED','FOLLOW-UP']

export default function Inbox() {
  const { profile } = useAuth()
  const { get: getCache, set: setCache } = useDataCache()
  const [leads, setLeads] = useState(() => {
    const cached = getCache('inbox_leads')
    return cached?.data || []
  })
  const [filter, setFilter] = useState('All')
  const [sortBy, setSortBy] = useState('lastInteraction')
  const location = useLocation()
  const [search, setSearch] = useState('')
  const [selectedLead, setSelectedLead] = useState(null)
  const [conversation, setConversation] = useState(null)
  const [reviews, setReviews] = useState([])
  const [activeReview, setActiveReview] = useState(null)
  const [replyMessages, setReplyMessages] = useState([])
  const [sending, setSending] = useState(false)
  const [loading, setLoading] = useState(() => {
    const cached = getCache('inbox_leads')
    return !cached?.data?.length
  })
  const [threadLoading, setThreadLoading] = useState(false)
  const [toast, setToast] = useState({ msg: '', type: '' })
  const [showTrainModal, setShowTrainModal] = useState(false)
  const [trainReason, setTrainReason] = useState('')
  const [correctedStage, setCorrectedStage] = useState(null)
  const [correctedIntent, setCorrectedIntent] = useState(null)
  const [showProfile, setShowProfile] = useState(false)
  const [botId, setBotId] = useState(null)
  const [showMobileThread, setShowMobileThread] = useState(false)
  const [manualReply, setManualReply] = useState('')
  const [manualSending, setManualSending] = useState(false)
  const [pendingLeadCount, setPendingLeadCount] = useState(0)
  const [aiProgress, setAiProgress] = useState(null)
  const [editingUsername, setEditingUsername] = useState(false)
  const [usernameInput, setUsernameInput] = useState('')
  const channelRef = useRef(null)
  const selectedLeadRef = useRef(null)
  const msgEndRef = useRef(null)
  const searchRef = useRef(null)
  const activeReviewRef = useRef(null)

  useEffect(() => {
    if (!profile) return
    loadData()
    return () => { if (channelRef.current) supabase.removeChannel(channelRef.current) }
  }, [profile])

  useEffect(() => {
    msgEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [conversation, reviews, activeReview])

  useEffect(() => {
    if (activeReview) {
      activeReviewRef.current = activeReview
      setCorrectedStage(activeReview.conversation_stage || null)
      setCorrectedIntent(activeReview.lead_intent || null)
    } else {
      activeReviewRef.current = null
    }
  }, [activeReview?.id])

  useEffect(() => {
    if (!location.state?.openLead || !leads.length || !botId) return
    const target = leads.find(l => String(l.customer_id) === String(location.state.openLead))
    if (target) selectLead(target)
  }, [location.state?.openLead, leads.length, botId])

  async function loadData() {
    const hasCached = leads.length > 0
    if (!hasCached) setLoading(true)
    const bot = await getAssignedBot(profile, 'id')
    if (!bot) { setLoading(false); return }
    setBotId(bot.id)

    const [{ data: allReviews }, { data: convos }, { data: pendingOnly }, { data: progressReviews }] = await Promise.all([
      supabase.from('reviews').select('*').eq('bot_id', bot.id).order('created_at', { ascending: false }),
      supabase.from('conversations').select('customer_id, channel, lead_intent, primary_goal, conversation_stage, profile_facts, running_summary, username, profile_name, updated_at, messages').eq('bot_id', bot.id).neq('channel', 'tester').order('updated_at', { ascending: false }),
      supabase.from('reviews').select('customer_id').eq('bot_id', bot.id).eq('status', 'pending').not('customer_id', 'ilike', 'tester_%'),
      supabase.from('reviews').select('id, status, confidence').eq('bot_id', bot.id).not('customer_id', 'ilike', 'tester_%')
    ])

    // Compute AI progress stats
    if (progressReviews) {
      const total = progressReviews.length
      const approved = progressReviews.filter(r => r.status === 'approved').length
      const approvalRate = total > 0 ? Math.round((approved / total) * 100) : 0
      const recentWithConf = progressReviews.filter(r => r.confidence != null).slice(-20)
      const avgConfidence = recentWithConf.length > 0
        ? Math.round((recentWithConf.reduce((a, r) => a + r.confidence, 0) / recentWithConf.length) * 100)
        : null
      let progressStage, progressPct
      if (approvalRate <= 40) { progressStage = 'Learning'; progressPct = Math.round((approvalRate / 40) * 33) }
      else if (approvalRate <= 65) { progressStage = 'Improving'; progressPct = 33 + Math.round(((approvalRate - 41) / 24) * 34) }
      else if (approvalRate <= 85) { progressStage = 'Trusted'; progressPct = 67 + Math.round(((approvalRate - 66) / 19) * 23) }
      else { progressStage = 'Auto-Ready'; progressPct = 90 + Math.round(((approvalRate - 86) / 14) * 10) }
      setAiProgress({ approvalRate, progressStage, progressPct, avgConfidence, total })
    }

    const leadsMap = {}

    ;(convos || []).filter(c => !c.username || !c.username.toLowerCase().startsWith('test')).forEach(c => {
      let identity = null, pf = {}
      try { pf = typeof c.profile_facts === 'string' ? JSON.parse(c.profile_facts) : (c.profile_facts || {}); identity = pf?.golf_identity || null } catch {}
      // Extract the last message sent by the lead (role: user/Lead) for the preview
      const msgs = Array.isArray(c.messages) ? c.messages : []
      let lastLeadMsg = ''
      for (let i = msgs.length - 1; i >= 0; i--) {
        const m = msgs[i]
        if (m.role === 'user' || m.role === 'Lead') { lastLeadMsg = m.content || ''; break }
      }
      leadsMap[c.customer_id] = {
        customer_id: c.customer_id, identity, username: c.username || null, profile_name: c.profile_name || null,
        lead_intent: c.lead_intent || null, channel: c.channel,
        primary_goal: c.primary_goal,
        conversation_stage: c.conversation_stage, running_summary: c.running_summary,
        profile_facts: pf, last_activity: c.updated_at,
        last_bot_sent_at: null,
        pending_count: 0, handoff_count: 0, latest_preview: lastLeadMsg, all_reviews: []
      }
    })

    ;(allReviews || []).forEach(r => {
      if (!leadsMap[r.customer_id]) {
        leadsMap[r.customer_id] = {
          customer_id: r.customer_id, identity: null, channel: 'tester',
          lead_intent: null, primary_goal: null, conversation_stage: r.conversation_stage,
          running_summary: null, profile_facts: {}, last_activity: r.created_at,
          pending_count: 0, handoff_count: 0, latest_preview: '', all_reviews: []
        }
      }
      leadsMap[r.customer_id].all_reviews.push(r)
      if (r.status === 'pending') leadsMap[r.customer_id].pending_count = 1
      if ((r.action_type === 'ESCALATE_TO_HUMAN' || r.action_type === 'HANDOFF_TO_SETTER') && r.status === 'pending') leadsMap[r.customer_id].handoff_count++
      // Track when the bot last sent a message (approved, edited, auto_sent)
      const isSentByBot = r.status === 'approved' || r.status === 'edited' || r.status === 'auto_sent'
      if (isSentByBot && r.resolved_at) {
        const prev = leadsMap[r.customer_id].last_bot_sent_at
        if (!prev || r.resolved_at > prev) leadsMap[r.customer_id].last_bot_sent_at = r.resolved_at
      }
    })

    const sorted = Object.values(leadsMap).sort((a, b) => {
      if (a.handoff_count > 0 && b.handoff_count === 0) return -1
      if (b.handoff_count > 0 && a.handoff_count === 0) return 1
      if (a.pending_count > 0 && b.pending_count === 0) return -1
      if (b.pending_count > 0 && a.pending_count === 0) return 1
      return new Date(b.last_activity) - new Date(a.last_activity)
    })

    // Unique leads with pending reviews — same logic as needsReply in Dashboard/Analytics
    setPendingLeadCount(new Set((pendingOnly || []).map(r => r.customer_id)).size)
    setLeads(sorted)
    setCache('inbox_leads', sorted)
    setLoading(false)

    if (channelRef.current) supabase.removeChannel(channelRef.current)
    const ch = supabase.channel(`inbox-${bot.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'reviews', filter: `bot_id=eq.${bot.id}` }, () => {
        loadData()
        setTimeout(() => {
          if (selectedLeadRef.current && !activeReviewRef.current) {
            loadThread(selectedLeadRef.current.customer_id, bot.id)
          }
        }, 1000)
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'conversations', filter: `bot_id=eq.${bot.id}` }, () => {
        loadData()
        setTimeout(() => {
          if (selectedLeadRef.current && !activeReviewRef.current) {
            loadThread(selectedLeadRef.current.customer_id, bot.id)
          }
        }, 2000)
      })
      .subscribe()
    channelRef.current = ch
    if (Notification.permission === 'default') Notification.requestPermission()
  }

  async function selectLead(lead) {
    selectedLeadRef.current = lead
    setSelectedLead(lead)
    setActiveReview(null)
    setReplyMessages([])
    setShowProfile(false)
    setShowMobileThread(true)
    setThreadLoading(true)
    setManualReply('')
    await loadThread(lead.customer_id, botId)
    setThreadLoading(false)
  }

  function goBackToList() {
    selectedLeadRef.current = null
    setSelectedLead(null)
    setShowMobileThread(false)
    setActiveReview(null)
    setReplyMessages([])
    setShowProfile(false)
    setManualReply('')
  }

  async function loadThread(customerId, bid) {
    const [{ data: convo }, { data: revs }] = await Promise.all([
      supabase.from('conversations').select('*').eq('bot_id', bid).eq('customer_id', customerId).single(),
      supabase.from('reviews').select('*').eq('bot_id', bid).eq('customer_id', customerId).order('created_at', { ascending: true })
    ])
    setConversation(convo || null)
    setReviews(revs || [])
    const firstPending = (revs || []).find(r => r.status === 'pending')
    if (firstPending) {
      setActiveReview(firstPending)
      const msgs = Array.isArray(firstPending.bot_messages) && firstPending.bot_messages.length > 0
        ? firstPending.bot_messages
        : [firstPending.bot_reply || '']
      setReplyMessages(msgs)
    }
  }

  function getReviewMessages(review) {
    // For sent reviews, show what was actually delivered (final), not the original draft
    if (review.status === 'approved' || review.status === 'edited' || review.status === 'auto_sent') {
      if (Array.isArray(review.final_messages) && review.final_messages.length > 0) return review.final_messages
      if (review.final_reply) return [review.final_reply]
    }
    if (Array.isArray(review.bot_messages) && review.bot_messages.length > 0) return review.bot_messages
    return [review.bot_reply || '']
  }

  function updateReplyMessage(idx, val) {
    setReplyMessages(prev => { const n = [...prev]; n[idx] = val; return n })
  }

  function addReplyMessage() {
    if (replyMessages.length >= 3) return
    setReplyMessages(prev => [...prev, ''])
  }

  function removeReplyMessage(idx) {
    if (replyMessages.length <= 1) return
    setReplyMessages(prev => prev.filter((_, i) => i !== idx))
  }

  async function sendToMake(customerId, messages, typingDelays) {
    try {
      await fetch('https://hook.eu2.make.com/jknvsf64c05m0urc1f7qph523pi310st', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customer_id: customerId,
          messages: messages.filter(m => m.trim()),
          typing_delays_ms: typingDelays && typingDelays.length > 0 ? typingDelays : messages.map(() => 1500)
        })
      })
    } catch (e) {
      console.error('Make webhook error:', e)
      throw e
    }
  }

  async function approve() {
    if (!activeReview) return
    setSending(true)
    const validMessages = replyMessages.filter(m => m.trim())
    const joinedReply = validMessages.join(' ')
    await supabase.from('reviews').update({
      status: 'approved', final_reply: joinedReply, final_messages: validMessages,
      resolved_at: new Date().toISOString(),
      ...(correctedStage ? { conversation_stage: correctedStage } : {}),
      ...(correctedIntent ? { lead_intent: correctedIntent } : {})
    }).eq('id', activeReview.id)

    // Update the matching message in conversations so the thread shows
    // the final sent text instead of the original draft
    if (conversation) {
      const updatedMessages = (conversation.messages || []).map(m => {
        if (m.review_id === activeReview.id) {
          return {
            ...m,
            content: joinedReply,
            bot_messages: validMessages,
            final_sent: true,
          }
        }
        return m
      })
      await supabase.from('conversations').update({
        messages: updatedMessages,
        ...(correctedStage ? { conversation_stage: correctedStage } : {}),
        ...(correctedIntent ? { lead_intent: correctedIntent } : {})
      }).eq('bot_id', botId).eq('customer_id', activeReview.customer_id)
    } else if (correctedStage || correctedIntent) {
      await supabase.from('conversations').update({
        ...(correctedStage ? { conversation_stage: correctedStage } : {}),
        ...(correctedIntent ? { lead_intent: correctedIntent } : {})
      }).eq('bot_id', botId).eq('customer_id', activeReview.customer_id)
    }

    await sendToMake(activeReview.customer_id, validMessages, activeReview.typing_delays || [])
    showToast('Approved - reply sent to lead', 'success')
    setSending(false)
    setActiveReview(null)
    setReplyMessages([])
    await loadThread(selectedLead.customer_id, botId)
    loadData()
  }

  async function saveTraining() {
    if (!trainReason.trim()) { showToast('Please add a reason', 'error'); return }
    setSending(true)
    const validMessages = replyMessages.filter(m => m.trim())
    const joinedReply = validMessages.join(' ')
    const originalJoined = activeReview.bot_reply || ''
    await supabase.from('reviews').update({
      status: 'edited', final_reply: joinedReply, final_messages: validMessages, resolved_at: new Date().toISOString()
    }).eq('id', activeReview.id)
    await supabase.from('learnings').insert({
      bot_id: botId, customer_id: activeReview.customer_id, review_id: activeReview.id,
      conversation_stage: correctedStage || activeReview.conversation_stage,
      original_reply: originalJoined, corrected_reply: joinedReply, corrected_messages: validMessages,
      reason: trainReason, source: 'inbox'
    })

    // Update the matching message in conversations so the thread shows
    // the final edited text instead of the original draft
    if (conversation) {
      const updatedMessages = (conversation.messages || []).map(m => {
        if (m.review_id === activeReview.id) {
          return {
            ...m,
            content: joinedReply,
            bot_messages: validMessages,
            final_sent: true,
          }
        }
        return m
      })
      await supabase.from('conversations').update({
        messages: updatedMessages,
        ...(correctedStage ? { conversation_stage: correctedStage } : {}),
        ...(correctedIntent ? { lead_intent: correctedIntent } : {})
      }).eq('bot_id', botId).eq('customer_id', activeReview.customer_id)
    } else if (correctedStage || correctedIntent) {
      await supabase.from('conversations').update({
        ...(correctedStage ? { conversation_stage: correctedStage } : {}),
        ...(correctedIntent ? { lead_intent: correctedIntent } : {})
      }).eq('bot_id', botId).eq('customer_id', activeReview.customer_id)
    }

    await sendToMake(activeReview.customer_id, validMessages, activeReview.typing_delays || [])
    setShowTrainModal(false)
    showToast('Edited - reply sent to lead', 'success')
    setSending(false)
    setActiveReview(null)
    setReplyMessages([])
    await loadThread(selectedLead.customer_id, botId)
    loadData()
  }

  async function discard() {
    if (!activeReview) return
    await supabase.from('reviews').update({ status: 'discarded', resolved_at: new Date().toISOString() }).eq('id', activeReview.id)
    showToast('Discarded', 'info')
    setActiveReview(null)
    setReplyMessages([])
    await loadThread(selectedLead.customer_id, botId)
    loadData()
  }

  async function sendManualReply() {
    if (!manualReply.trim() || !selectedLead || !botId) return
    setManualSending(true)
    const text = manualReply.trim()
    setManualReply('')

    // 1. Save to conversations table — append to messages array
    const currentMessages = conversation?.messages || []
    const newMessage = {
      role: 'assistant',
      content: text,
      bot_messages: [text],
      timestamp: Date.now(),
      manual: true
    }
    const updatedMessages = [...currentMessages, newMessage]

    await supabase.from('conversations')
      .update({ messages: updatedMessages, updated_at: new Date().toISOString() })
      .eq('bot_id', botId)
      .eq('customer_id', selectedLead.customer_id)

    // 2. Deliver to Instagram via Make
    try {
      await sendToMake(selectedLead.customer_id, [text], [1500])
      showToast('Manual reply sent', 'success')
    } catch (e) {
      showToast('Saved but failed to deliver to Instagram', 'error')
    }

    // 3. Reload thread so message appears immediately
    await loadThread(selectedLead.customer_id, botId)
    setManualSending(false)
  }

  function showToast(msg, type = 'success') { setToast({ msg, type }); setTimeout(() => setToast({ msg: '' }), 3000) }

  async function saveUsername() {
    if (!selectedLead || !botId) return
    const newUsername = usernameInput.trim().replace(/^@/, '')
    if (!newUsername) return
    const { error } = await supabase.from('conversations')
      .update({ username: newUsername, updated_at: new Date().toISOString() })
      .eq('bot_id', botId)
      .eq('customer_id', selectedLead.customer_id)
    if (error) { showToast('Failed to save username', 'error'); return }
    // Update local state so it reflects immediately
    setSelectedLead(prev => ({ ...prev, username: newUsername }))
    setLeads(prev => prev.map(l => l.customer_id === selectedLead.customer_id ? { ...l, username: newUsername } : l))
    setEditingUsername(false)
    showToast('Username updated', 'success')
  }

  function getLeadName(lead) {
    if (!lead) return ''
    if (String(lead.customer_id).startsWith('tester_')) return 'Bot Tester'
    const ch = (lead.channel || '').toLowerCase()
    const isFb = ch.includes('facebook') || ch === 'fb'
    if (isFb) { if (lead.profile_name) return lead.profile_name; if (lead.username) return `@${lead.username}`; return 'Facebook Lead' }
    if (lead.username) return `@${lead.username}`
    if (lead.profile_name) return lead.profile_name
    if (lead.identity) return lead.identity
    if (ch.includes('instagram') || ch === 'manychat' || ch === 'ig') return 'Instagram Lead'
    if (ch.includes('whatsapp') || ch === 'wa') return 'WhatsApp Lead'
    if (ch.includes('sms')) return 'SMS Lead'
    if (ch.includes('email')) return 'Email Lead'
    if (ch === 'tester') return 'Bot Tester'
    return 'Instagram Lead'
  }

  function timeAgo(dateStr) {
    if (!dateStr) return ''
    const diff = Date.now() - new Date(dateStr).getTime()
    const mins = Math.floor(diff / 60000)
    if (mins < 1) return 'Just now'
    if (mins < 60) return `${mins}m ago`
    const hrs = Math.floor(mins / 60)
    if (hrs < 24) return `${hrs}h ago`
    const days = Math.floor(hrs / 24)
    if (days === 1) return 'Yesterday'
    if (days < 7) return `${days}d ago`
    return new Date(dateStr).toLocaleDateString()
  }

  function intentBadgeStyle(intent, stage) {
    if (stage === 'BOOKED' || stage === 'SCHEDULE') return { color: '#16a34a', background: '#f0fdf4', border: '1px solid #bbf7d0' }
    if (intent === 'HIGH') return { color: '#e53e3e', background: '#fff5f5', border: '1px solid #fed7d7' }
    if (intent === 'MEDIUM') return { color: '#d97706', background: '#fffbeb', border: '1px solid #fde68a' }
    return { color: '#6b7280', background: '#f9fafb', border: '1px solid #e5e7eb' }
  }

  function intentEmoji(intent, stage) {
    if (stage === 'BOOKED' || stage === 'SCHEDULE') return '\u2705'
    if (intent === 'HIGH') return '\uD83D\uDD34'
    if (intent === 'MEDIUM') return '\uD83D\uDFE1'
    return '\u26AA'
  }

  function fmtTime(ts) { if (!ts) return ''; return timeAgo(ts) }

  function fmtDate(ts) {
    if (!ts) return ''
    const d = new Date(ts), now = new Date()
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())
    const msgDay = new Date(d.getFullYear(), d.getMonth(), d.getDate())
    const diff = today - msgDay
    if (diff === 0) return 'Today'
    if (diff === 86400000) return 'Yesterday'
    return d.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' })
  }

  function buildTimeline() {
    const messages = conversation?.messages || []
    const reviewMap = {}
    reviews.forEach(r => { if (r.id) reviewMap[r.id] = r })
    const items = []
    let lastDate = null
    messages.forEach((m, i) => {
      const ts = m.timestamp ? new Date(m.timestamp) : null
      const dateLabel = ts ? fmtDate(ts) : null
      if (dateLabel && dateLabel !== lastDate) { items.push({ type: 'separator', label: dateLabel, key: `sep-${i}` }); lastDate = dateLabel }
      const botMessages = m.bot_messages || (m.content ? [m.content] : [])
      items.push({ type: 'message', ...m, botMessages, _index: i, _review: m.review_id ? reviewMap[m.review_id] : null, key: `msg-${i}` })
    })
    return items
  }

  const sortedLeads = [...leads].sort((a, b) => {
    if (sortBy === 'intent') { const order = { HIGH: 0, MEDIUM: 1, LOW: 2 }; return (order[a.lead_intent] ?? 3) - (order[b.lead_intent] ?? 3) }
    if (sortBy === 'stage') return (a.conversation_stage || '').localeCompare(b.conversation_stage || '')
    return new Date(b.last_activity || 0) - new Date(a.last_activity || 0)
  })

  const filteredLeads = sortedLeads.filter(l => {
    const matchesSearch = !search || getLeadName(l).toLowerCase().includes(search.toLowerCase()) || String(l.customer_id).includes(search) || (l.username && l.username.toLowerCase().includes(search.toLowerCase().replace('@', ''))) || (l.profile_name && l.profile_name.toLowerCase().includes(search.toLowerCase()))
    const isTester = String(l.customer_id).startsWith('tester_') || l.channel === 'tester'
    // Follow Ups: bot sent last message, lead hasn't replied in 21+ hours, no pending review
    const isFollowUp = (() => {
      if (isTester || l.pending_count > 0 || !l.last_bot_sent_at) return false
      const hoursSinceBotSent = (Date.now() - new Date(l.last_bot_sent_at).getTime()) / 3600000
      // Only flag if last_activity hasn't been updated significantly after the bot sent
      // i.e. the lead hasn't replied (last_activity ~ last_bot_sent_at)
      const lastActivityMs = new Date(l.last_activity).getTime()
      const lastBotMs = new Date(l.last_bot_sent_at).getTime()
      const leadRepliedAfter = lastActivityMs > lastBotMs + 5 * 60000 // 5 min buffer
      return hoursSinceBotSent >= FOLLOW_UP_HOURS && !leadRepliedAfter
    })()
    const matchesFilter = filter === 'Test'
      ? isTester
      : isTester ? false
      : filter === 'All' ? true
      : filter === 'Pending' ? l.pending_count > 0
      : filter === 'Follow Ups' ? isFollowUp
      : filter === 'Escalated' ? l.handoff_count > 0
      : filter === 'Resolved' ? l.pending_count === 0 && l.all_reviews.length > 0
      : true
    return matchesSearch && matchesFilter
  })

  const totalPending = pendingLeadCount
  const timeline = selectedLead ? buildTimeline() : []

  if (loading) return <div className="page" style={{ alignItems: 'center', justifyContent: 'center' }}><div className="spinner" /></div>

  return (
    <div className="inbox-wrapper">
      {toast.msg && <div className={`toast ${toast.type === 'error' ? 'toast-error' : ''}`}>{toast.msg}</div>}

      {/* ═══ LEFT: LEAD LIST ═══ */}
      <div className="inbox-list" style={{ display: selectedLead ? 'none' : 'flex' }}>
        <div style={{ padding: '12px 12px 8px' }}>
          <div style={{ position: 'relative' }}>
            <span style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)', color: 'var(--tx3)', fontSize: '.84rem', pointerEvents: 'none' }}>{'\uD83D\uDD0D'}</span>
            <input ref={searchRef} value={search} onChange={e => setSearch(e.target.value)} placeholder="Search leads..." style={{ width: '100%', padding: '8px 10px 8px 32px', background: 'var(--surf2)', border: '1px solid var(--bdr)', borderRadius: '20px', fontSize: '.83rem', color: 'var(--tx)', outline: 'none', boxSizing: 'border-box', fontFamily: 'var(--fn)' }} />
            {search && <button onClick={() => setSearch('')} style={{ position: 'absolute', right: '10px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--tx3)', fontSize: '.8rem', padding: 0 }}>{'\u2715'}</button>}
          </div>
        </div>

        <div style={{ padding: '0 10px 10px', display: 'flex', flexDirection: 'column', gap: '8px', flexShrink: 0 }}>
          <div style={{ display: 'flex', gap: '4px', overflowX: 'auto', paddingBottom: '2px', scrollbarWidth: 'none', msOverflowStyle: 'none' }}>
            {FILTERS.map(f => {
              const followUpLeads = leads.filter(l => {
                if (String(l.customer_id).startsWith('tester_') || l.channel === 'tester' || l.pending_count > 0 || !l.last_bot_sent_at) return false
                const hrs = (Date.now() - new Date(l.last_bot_sent_at).getTime()) / 3600000
                const leadReplied = new Date(l.last_activity).getTime() > new Date(l.last_bot_sent_at).getTime() + 5 * 60000
                return hrs >= FOLLOW_UP_HOURS && !leadReplied
              })
              const count = f === 'Pending' ? totalPending
                : f === 'Escalated' ? leads.reduce((a, l) => a + l.handoff_count, 0)
                : f === 'Follow Ups' ? followUpLeads.length
                : f === 'Test' ? leads.filter(l => String(l.customer_id).startsWith('tester_') || l.channel === 'tester').length
                : null
              return (
                <button key={f} onClick={() => setFilter(f)} style={{
                  flexShrink: 0, padding: '5px 10px', borderRadius: '8px', border: 'none', cursor: 'pointer',
                  fontSize: '.72rem', fontWeight: filter === f ? 600 : 400, whiteSpace: 'nowrap',
                  background: filter === f ? (f === 'Test' ? '#6b7280' : f === 'Follow Ups' ? '#d97706' : 'var(--acc)') : 'var(--surf2)',
                  color: filter === f ? '#fff' : f === 'Test' ? 'var(--tx3)' : f === 'Follow Ups' ? '#d97706' : 'var(--tx2)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px', transition: 'all .15s'
                }}>
                  {f}
                  {count > 0 && (
                    <span style={{
                      background: filter === f ? 'rgba(255,255,255,.3)' : f === 'Test' ? '#6b7280' : f === 'Follow Ups' ? '#d97706' : '#e53e3e',
                      color: '#fff', borderRadius: '999px', fontSize: '.6rem',
                      minWidth: '14px', height: '14px', display: 'inline-flex',
                      alignItems: 'center', justifyContent: 'center', padding: '0 3px'
                    }}>{count}</span>
                  )}
                </button>
              )
            })}
          </div>
          <select value={sortBy} onChange={e => setSortBy(e.target.value)} style={{ width: '100%', padding: '5px 8px', borderRadius: '8px', border: '1px solid var(--bdr)', background: 'var(--surf2)', color: 'var(--tx2)', fontSize: '.72rem', cursor: 'pointer', fontFamily: 'var(--fn)' }}>
            <option value="lastInteraction">Sort: Last Interaction</option>
            <option value="intent">Sort: Intent (High first)</option>
            <option value="stage">Sort: Conversation Stage</option>
          </select>
        </div>

        <div style={{ flex: 1, overflowY: 'auto' }}>
          {filteredLeads.length === 0 ? (
            <div style={{ padding: '40px 20px', textAlign: 'center', color: 'var(--tx3)', fontSize: '.84rem' }}>{search ? 'No leads match your search' : 'No conversations yet'}</div>
          ) : filteredLeads.map(lead => {
            const isSelected = selectedLead?.customer_id === lead.customer_id
            const isFollowUpLead = (() => {
              if (String(lead.customer_id).startsWith('tester_') || lead.channel === 'tester' || lead.pending_count > 0 || !lead.last_bot_sent_at) return false
              const hrs = (Date.now() - new Date(lead.last_bot_sent_at).getTime()) / 3600000
              const leadReplied = new Date(lead.last_activity).getTime() > new Date(lead.last_bot_sent_at).getTime() + 5 * 60000
              return hrs >= FOLLOW_UP_HOURS && !leadReplied
            })()
            return (
              <div key={lead.customer_id} onClick={() => selectLead(lead)} style={{ padding: '12px 14px', cursor: 'pointer', borderBottom: '1px solid var(--bdr)', background: isSelected ? 'var(--accp)' : 'transparent', borderLeft: isSelected ? '3px solid var(--acc)' : '3px solid transparent', transition: 'background .15s' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <div style={{ width: 38, height: 38, borderRadius: '50%', background: 'var(--acc)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '.9rem', fontWeight: 700, color: '#fff', flexShrink: 0 }}>{getLeadName(lead).charAt(0).toUpperCase()}</div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                      <span style={{ fontWeight: 600, fontSize: '.86rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{getLeadName(lead)}</span>
                      {lead.lead_intent === 'HIGH' && <span style={{ fontSize: '.75rem', flexShrink: 0 }}>{'\uD83D\uDD34'}</span>}
                      {lead.lead_intent === 'MEDIUM' && <span style={{ fontSize: '.75rem', flexShrink: 0 }}>{'\uD83D\uDFE1'}</span>}
                      {lead.lead_intent === 'LOW' && <span style={{ fontSize: '.75rem', flexShrink: 0 }}>{'\u26AA'}</span>}
                      {lead.handoff_count > 0 && <span style={{ fontSize: '.68rem', background: '#e53e3e', color: '#fff', padding: '1px 6px', borderRadius: '999px', flexShrink: 0 }}>{'\uD83D\uDEA8'}</span>}
                      {lead.pending_count > 0 && lead.handoff_count === 0 && <span style={{ fontSize: '.68rem', background: '#d97706', color: '#fff', padding: '1px 6px', borderRadius: '999px', flexShrink: 0 }}>{lead.pending_count}</span>}
                      {isFollowUpLead && <span style={{ fontSize: '.68rem', background: '#fff7ed', color: '#d97706', border: '1px solid #fed7aa', padding: '1px 5px', borderRadius: '999px', flexShrink: 0 }}>⏰ Follow up</span>}
                    </div>
                    <div style={{ fontSize: '.76rem', color: 'var(--tx3)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', marginTop: '2px' }}>{lead.latest_preview || lead.conversation_stage || 'No messages yet'}</div>
                  </div>
                  <div style={{ fontSize: '.68rem', color: 'var(--tx3)', flexShrink: 0 }}>{fmtTime(lead.last_activity)}</div>
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* ═══ CENTER + RIGHT: THREAD VIEW ═══ */}
      <div className="inbox-thread" style={{ display: selectedLead ? 'flex' : 'none' }}>
        {!selectedLead ? (
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--tx3)', fontSize: '.9rem' }}>Select a conversation to view</div>
        ) : (
          <>
            {/* Header */}
            <div style={{ padding: '10px 16px', borderBottom: '1px solid var(--bdr)', display: 'flex', alignItems: 'center', gap: '12px', background: 'var(--surf)', flexShrink: 0 }}>
              <button onClick={goBackToList} className="back-btn">
                {'\u2190'} <span style={{ fontSize: '.8rem', fontWeight: 500 }}>Back</span>
              </button>
              <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'var(--acc)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '.95rem', fontWeight: 700, color: '#fff' }}>{getLeadName(selectedLead).charAt(0).toUpperCase()}</div>
              <div style={{ minWidth: 0, flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: '.9rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{getLeadName(selectedLead)}</div>
                <div style={{ fontSize: '.72rem', color: 'var(--tx3)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{selectedLead.conversation_stage || 'Unknown stage'}</div>
              </div>
              <div style={{ display: 'flex', gap: '6px', alignItems: 'center', flexShrink: 0 }}>
                {selectedLead.lead_intent && (
                  <span style={{ fontSize: '.68rem', fontWeight: 700, padding: '2px 8px', borderRadius: '999px', ...intentBadgeStyle(selectedLead.lead_intent, selectedLead.conversation_stage) }}>
                    {intentEmoji(selectedLead.lead_intent, selectedLead.conversation_stage)} {(selectedLead.conversation_stage === 'BOOKED' || selectedLead.conversation_stage === 'SCHEDULE') ? 'Booked' : selectedLead.lead_intent}
                  </span>
                )}
                <button onClick={() => setShowProfile(p => !p)} style={{ background: showProfile ? 'var(--accl)' : 'var(--surf2)', border: '1px solid var(--bdr)', borderRadius: '8px', padding: '5px 10px', cursor: 'pointer', fontSize: '.75rem', color: showProfile ? 'var(--acc)' : 'var(--tx2)', fontWeight: showProfile ? 600 : 400 }}>Profile</button>
              </div>
            </div>

            {/* Main content area: Conversation + AI Assistant side by side */}
            <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>

              {/* LEFT: Conversation + Manual Reply */}
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
                {/* Messages */}
                <div style={{ flex: 1, overflowY: 'auto', padding: '16px 20px', display: 'flex', flexDirection: 'column', gap: '2px' }}>
                  {threadLoading ? (
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 1 }}><div className="spinner" /></div>
                  ) : timeline.length === 0 ? (
                    <div style={{ textAlign: 'center', color: 'var(--tx3)', fontSize: '.84rem', padding: '60px 0' }}>No conversation history yet.</div>
                  ) : timeline.map(item => {
                    if (item.type === 'separator') return (
                      <div key={item.key} style={{ display: 'flex', alignItems: 'center', gap: '12px', margin: '14px 0 10px' }}>
                        <div style={{ flex: 1, height: '1px', background: 'var(--bdr)' }} />
                        <span style={{ fontSize: '.69rem', color: 'var(--tx3)', background: '#e8ede8', padding: '3px 10px', borderRadius: '999px', fontWeight: 500, whiteSpace: 'nowrap' }}>{item.label}</span>
                        <div style={{ flex: 1, height: '1px', background: 'var(--bdr)' }} />
                      </div>
                    )
                    const isLead = item.role === 'user' || item.role === 'Lead'
                    const isManual = item.manual === true
                    const review = item._review
                    const isPending = review?.status === 'pending'
                    const isActive = activeReview?.id === review?.id
                    const isSent = review && (review.status === 'approved' || review.status === 'edited' || review.status === 'auto_sent')
                    const isDiscarded = review?.status === 'discarded'
                    // For sent reviews show final delivered text; for pending show draft; fallback to message content
                    const botMessages = isLead ? null
                      : isSent ? (Array.isArray(review.final_messages) && review.final_messages.length > 0 ? review.final_messages : review.final_reply ? [review.final_reply] : (item.botMessages || [item.content]))
                      : (item.botMessages || [item.content])
                    const showMultiple = !isLead && botMessages && botMessages.length > 1
                    return (
                      <div key={item.key} style={{ display: 'flex', flexDirection: 'column', alignItems: isLead ? 'flex-start' : 'flex-end', marginBottom: '6px' }}>
                        <div style={{ maxWidth: 'min(80%, 560px)', display: 'flex', flexDirection: 'column', alignItems: isLead ? 'flex-start' : 'flex-end', gap: showMultiple ? '4px' : 0 }}>
                          {isLead && (
                            <div style={{ padding: '9px 13px', borderRadius: '2px 16px 16px 16px', fontSize: '.84rem', lineHeight: 1.6, whiteSpace: 'pre-wrap', wordBreak: 'break-word', background: '#fff', color: 'var(--tx)', border: '1px solid rgba(0,0,0,.06)', boxShadow: '0 1px 2px rgba(0,0,0,.08)' }}>{item.content}</div>
                          )}
                          {/* AI suggested — small button below lead's last message, opens review panel on click */}
                          {isLead && (() => {
                            const nextPendingReview = reviews.find(r => r.status === 'pending')
                            const timelineItems = timeline.filter(t => t.type === 'message')
                            const thisIdx = timelineItems.findIndex(t => t.key === item.key)
                            const nextItem = timelineItems[thisIdx + 1]
                            const isLastLeadMsg = !nextItem || (nextItem._review?.status === 'pending')
                            if (!nextPendingReview || !isLastLeadMsg) return null
                            return (
                              <div style={{ marginTop: '6px', display: 'flex', justifyContent: 'flex-end' }}>
                                <button
                                  onClick={() => { setActiveReview(nextPendingReview); setReplyMessages(getReviewMessages(nextPendingReview)) }}
                                  style={{ display: 'flex', alignItems: 'center', gap: '5px', padding: '4px 10px', background: '#fef3c7', color: '#92400e', border: '1px solid #fde68a', borderRadius: '999px', fontSize: '.72rem', fontWeight: 600, cursor: 'pointer', transition: 'all .15s' }}
                                  onMouseEnter={e => { e.currentTarget.style.background = '#fde68a' }}
                                  onMouseLeave={e => { e.currentTarget.style.background = '#fef3c7' }}
                                >
                                  🤖 AI Reply Ready — Review
                                </button>
                              </div>
                            )
                          })()}
                          {/* Pending bot bubble — hidden from thread (shown only in sidebar via the button above) */}
                          {!isLead && !isPending && botMessages.map((bubble, bi) => (
                            <div key={bi} onClick={() => null}
                              style={{ padding: '9px 13px', borderRadius: '16px 2px 16px 16px', fontSize: '.84rem', lineHeight: 1.6, whiteSpace: 'pre-wrap', wordBreak: 'break-word', background: isDiscarded ? 'var(--surf2)' : isManual ? '#e8f0fe' : 'var(--acc)', color: isDiscarded ? 'var(--tx3)' : isManual ? '#1a3a8f' : '#e8f7ed', border: isActive ? '2px solid var(--acc)' : isDiscarded ? '1px dashed var(--bdr)' : isManual ? '1px solid #c7d7fc' : 'none', boxShadow: '0 1px 2px rgba(0,0,0,.08)', cursor: 'default', transition: 'all .15s', opacity: isDiscarded ? 0.5 : 1, textDecoration: isDiscarded ? 'line-through' : 'none' }}>
                              {bubble}
                            </div>
                          ))}
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '4px', marginTop: '3px', padding: '0 2px' }}>
                          <span style={{ fontSize: '.65rem', color: 'var(--tx3)' }}>{item.timestamp ? fmtTime(new Date(item.timestamp)) : ''}</span>
                          {!isLead && isManual && <span style={{ fontSize: '.65rem', color: 'var(--acc)', fontWeight: 600 }}>{'\u2713\u2713'} Sent</span>}
                          {!isLead && !isManual && botMessages && botMessages.length > 1 && <span style={{ fontSize: '.65rem', color: 'var(--blu)' }}>{botMessages.length} msgs</span>}
                          {!isLead && !isManual && isSent && <span style={{ fontSize: '.65rem', color: 'var(--acc)', fontWeight: 600 }}>{'\u2713\u2713'} Sent</span>}
                          {!isLead && review?.status === 'discarded' && <span style={{ fontSize: '.65rem', color: 'var(--tx3)' }}>{'\u2715'} Discarded</span>}
                        </div>
                      </div>
                    )
                  })}
                  <div ref={msgEndRef} />
                </div>

                {/* Manual Reply Input */}
                <div style={{ padding: '10px 16px', borderTop: '1px solid var(--bdr)', background: 'var(--surf)', display: 'flex', gap: '8px', alignItems: 'center', flexShrink: 0 }}>
                  <input
                    value={manualReply}
                    onChange={e => setManualReply(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendManualReply() } }}
                    placeholder="Type a manual reply..."
                    disabled={manualSending}
                    style={{ flex: 1, padding: '10px 14px', background: 'var(--surf2)', border: '1px solid var(--bdr)', borderRadius: '12px', fontSize: '.84rem', color: 'var(--tx)', outline: 'none', fontFamily: 'var(--fn)', boxSizing: 'border-box', opacity: manualSending ? .6 : 1 }}
                  />
                  <button
                    onClick={sendManualReply}
                    disabled={!manualReply.trim() || manualSending}
                    style={{ padding: '10px 18px', background: manualReply.trim() && !manualSending ? 'var(--acc)' : 'var(--surf2)', border: 'none', borderRadius: '12px', cursor: manualReply.trim() && !manualSending ? 'pointer' : 'default', fontSize: '.84rem', color: manualReply.trim() && !manualSending ? '#fff' : 'var(--tx3)', fontWeight: 600, transition: 'all .15s' }}
                  >{manualSending ? 'Sending...' : 'Send'}</button>
                </div>
              </div>

              {/* RIGHT: AI Assistant Panel (only when pending review exists) */}
              {activeReview && (
                <div className="ai-panel">
                  <div style={{ overflowY: 'auto', flex: 1, display: 'flex', flexDirection: 'column', gap: '16px' }}>

                    {/* Panel Header */}
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                      <div style={{ fontSize: '.95rem', fontWeight: 700, color: 'var(--tx)' }}>AI Assistant</div>
                      <button onClick={() => { setActiveReview(null); activeReviewRef.current = null; setReplyMessages([]) }} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--tx3)', fontSize: '1rem' }}>{'\u2715'}</button>
                    </div>

                    {/* AI Insight */}
                    {activeReview.internal_notes && (
                      <div style={{ background: '#fffbeb', border: '1px solid #fde68a', borderRadius: '10px', padding: '12px 14px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
                          <span style={{ fontSize: '.95rem' }}>{'\uD83D\uDCA1'}</span>
                          <span style={{ fontSize: '.78rem', fontWeight: 700, color: '#92400e', textTransform: 'uppercase', letterSpacing: '.05em' }}>AI Insight</span>
                        </div>
                        <div style={{ fontSize: '.8rem', color: '#78350f', lineHeight: 1.65 }}>{activeReview.internal_notes}</div>
                      </div>
                    )}

                    {/* AI Progress */}
                    {aiProgress && (
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>

                        {/* Notice — Learning/Improving = orange warning, Trusted/Auto-Ready = green */}
                        {(aiProgress.progressStage === 'Learning' || aiProgress.progressStage === 'Improving') ? (
                          <div style={{ background: '#fff7ed', borderLeft: '3px solid #f97316', borderRadius: '0 8px 8px 0', padding: '9px 12px', border: '1px solid #fed7aa', borderLeft: '3px solid #f97316' }}>
                            <div style={{ fontSize: '.76rem', fontWeight: 600, color: '#9a3412', marginBottom: '2px' }}>AI is still learning — review all replies</div>
                            <div style={{ fontSize: '.71rem', color: '#c2410c', lineHeight: 1.5 }}>The AI needs 66% approval rate before its replies can be trusted. Currently at {aiProgress.approvalRate}%. Correct anything that doesn't sound right.</div>
                          </div>
                        ) : (
                          <div style={{ background: '#f0fdf4', borderLeft: '3px solid #16a34a', borderRadius: '0 8px 8px 0', padding: '9px 12px', border: '1px solid #bbf7d0', borderLeft: '3px solid #16a34a' }}>
                            <div style={{ fontSize: '.76rem', fontWeight: 600, color: '#15803d', marginBottom: '2px' }}>✓ AI is performing well</div>
                            <div style={{ fontSize: '.71rem', color: '#166534', lineHeight: 1.5 }}>{aiProgress.approvalRate}% approval rate — {aiProgress.progressStage}. Replies are reliable but always worth a quick check.</div>
                          </div>
                        )}

                        {/* Progress bar */}
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <span style={{ fontSize: '.72rem', fontWeight: 600, padding: '1px 8px', borderRadius: '999px',
                              background: aiProgress.progressStage === 'Auto-Ready' || aiProgress.progressStage === 'Trusted' ? '#f0fdf4' : aiProgress.progressStage === 'Improving' ? '#faeeda' : '#e6f1fb',
                              color: aiProgress.progressStage === 'Auto-Ready' || aiProgress.progressStage === 'Trusted' ? '#15803d' : aiProgress.progressStage === 'Improving' ? '#854f0b' : '#185fa5'
                            }}>{aiProgress.progressStage}</span>
                            <span style={{ fontSize: '.71rem', color: 'var(--tx3)' }}>{aiProgress.approvalRate}% approval</span>
                          </div>
                          <div style={{ height: '5px', background: 'var(--surf3)', borderRadius: '100px', overflow: 'hidden', border: '1px solid var(--bdr)' }}>
                            <div style={{ height: '100%', borderRadius: '100px', transition: 'width 1s ease',
                              width: `${aiProgress.progressPct}%`,
                              background: aiProgress.progressStage === 'Auto-Ready' ? '#16a34a' : aiProgress.progressStage === 'Trusted' ? '#2d6a4f' : aiProgress.progressStage === 'Improving' ? '#d97706' : '#378add'
                            }} />
                          </div>
                          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                            {['Learning', 'Improving', 'Trusted', 'Auto-Ready'].map(s => (
                              <span key={s} style={{ fontSize: '.62rem', color: aiProgress.progressStage === s ? 'var(--acc)' : 'var(--tx3)', fontWeight: aiProgress.progressStage === s ? 700 : 400 }}>{s}</span>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Escalation Warning */}
                    {(activeReview.action_type === 'ESCALATE_TO_HUMAN' || activeReview.action_type === 'HANDOFF_TO_SETTER') && (
                      <div style={{ background: '#fff5f5', border: '1px solid #fed7d7', borderRadius: '10px', padding: '10px 14px' }}>
                        <div style={{ fontSize: '.78rem', fontWeight: 600, color: '#e53e3e', marginBottom: '4px' }}>{'\uD83D\uDEA8'} Escalated to Human</div>
                        {activeReview.escalation_reason && <div style={{ fontSize: '.76rem', color: '#991b1b', lineHeight: 1.5 }}>{activeReview.escalation_reason}</div>}
                      </div>
                    )}

                    {/* Lead Intent */}
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
                        <span style={{ fontSize: '.82rem', fontWeight: 600, color: 'var(--tx)' }}>Lead Intent</span>
                        <span style={{ fontSize: '.72rem', fontWeight: 700, padding: '3px 10px', borderRadius: '999px', ...intentBadgeStyle(correctedIntent || activeReview.lead_intent, correctedStage || activeReview.conversation_stage) }}>
                          {correctedIntent || activeReview.lead_intent || 'UNKNOWN'}
                        </span>
                      </div>
                      <div style={{ display: 'flex', gap: '4px' }}>
                        {['LOW', 'MEDIUM', 'HIGH'].map(i => (
                          <button key={i} onClick={() => setCorrectedIntent(i)} style={{
                            flex: 1, padding: '6px', borderRadius: '6px', border: 'none', cursor: 'pointer', fontSize: '.72rem', fontWeight: 600,
                            background: correctedIntent === i ? (i === 'HIGH' ? '#e53e3e' : i === 'MEDIUM' ? '#d97706' : '#6b7280') : 'var(--surf2)',
                            color: correctedIntent === i ? '#fff' : 'var(--tx3)',
                            outline: correctedIntent === i ? 'none' : '1px solid var(--bdr)'
                          }}>{i}</button>
                        ))}
                      </div>
                    </div>

                    {/* Conversation Stage */}
                    <div>
                      <div style={{ fontSize: '.82rem', fontWeight: 600, color: 'var(--tx)', marginBottom: '6px' }}>Conversation Stage</div>
                      <select value={correctedStage || ''} onChange={e => setCorrectedStage(e.target.value)}
                        style={{ width: '100%', fontSize: '.78rem', padding: '7px 10px', borderRadius: '8px', border: correctedStage !== activeReview.conversation_stage ? '1.5px solid var(--acc)' : '1px solid var(--bdr)', background: correctedStage !== activeReview.conversation_stage ? 'var(--accp)' : 'var(--surf2)', color: 'var(--tx)', cursor: 'pointer', fontFamily: 'var(--fn)', boxSizing: 'border-box' }}>
                        {STAGES.map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                    </div>

                    {/* Suggested Reply */}
                    <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
                        <div style={{ fontSize: '.82rem', fontWeight: 600, color: 'var(--tx)' }}>Suggested Reply</div>
                        <span style={{ fontSize: '.68rem', background: '#fef3c7', color: '#92400e', border: '1px solid #fde68a', padding: '1px 7px', borderRadius: '999px', fontWeight: 600 }}>AI Draft</span>
                      </div>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', flex: 1 }}>
                        {replyMessages.map((msg, idx) => (
                          <div key={idx} style={{ position: 'relative' }}>
                            <textarea
                              value={msg}
                              onChange={e => updateReplyMessage(idx, e.target.value)}
                              rows={3}
                              style={{ width: '100%', background: '#fffdf0', border: '1px solid #fde68a', color: 'var(--tx)', fontFamily: 'var(--fn)', fontSize: '.82rem', padding: '8px 30px 8px 10px', borderRadius: '8px', resize: 'vertical', outline: 'none', lineHeight: 1.55, boxSizing: 'border-box' }}
                              onFocus={e => { e.target.style.borderColor = '#d97706'; e.target.style.background = '#fffbeb' }}
                              onBlur={e => { e.target.style.borderColor = '#fde68a'; e.target.style.background = '#fffdf0' }}
                              placeholder={`Message ${idx + 1}...`}
                            />
                            {replyMessages.length > 1 && (
                              <button onClick={() => removeReplyMessage(idx)} style={{ position: 'absolute', top: '6px', right: '6px', width: '18px', height: '18px', borderRadius: '50%', background: '#fed7d7', border: 'none', cursor: 'pointer', fontSize: '.6rem', color: '#e53e3e', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{'\u00D7'}</button>
                            )}
                          </div>
                        ))}
                        {replyMessages.length < 3 && (
                          <button onClick={addReplyMessage} style={{ alignSelf: 'flex-start', padding: '4px 10px', background: 'var(--surf2)', border: '1px dashed var(--bdr)', borderRadius: '6px', cursor: 'pointer', fontSize: '.72rem', color: 'var(--tx3)' }}>+ Add message</button>
                        )}
                      </div>
                    </div>

                  </div>

                  {/* Action Buttons - pinned to bottom */}
                  <div style={{ borderTop: '1px solid var(--bdr)', paddingTop: '12px', display: 'flex', gap: '6px', alignItems: 'center', flexShrink: 0 }}>
                    <button onClick={() => { setTrainReason(''); setShowTrainModal(true) }}
                      style={{ padding: '8px 14px', background: 'var(--surf2)', border: '1px solid var(--bdr)', borderRadius: '8px', cursor: 'pointer', fontSize: '.78rem', color: 'var(--tx2)', fontWeight: 500, display: 'flex', alignItems: 'center', gap: '4px' }}>
                      {'\u270F'} Edit
                    </button>
                    <button onClick={discard}
                      style={{ padding: '8px 12px', background: '#fff5f5', border: '1px solid #fed7d7', borderRadius: '8px', cursor: 'pointer', fontSize: '.78rem', color: '#e53e3e', fontWeight: 500 }}>
                      {'\u2715'} Discard
                    </button>
                    <button onClick={approve} disabled={sending || replyMessages.filter(m => m.trim()).length === 0}
                      style={{ marginLeft: 'auto', padding: '8px 18px', background: 'var(--acc)', border: 'none', borderRadius: '8px', cursor: sending ? 'not-allowed' : 'pointer', fontSize: '.82rem', color: '#fff', fontWeight: 600, opacity: sending || replyMessages.filter(m => m.trim()).length === 0 ? .7 : 1, boxShadow: '0 2px 8px rgba(45,106,79,.25)' }}>
                      {sending ? 'Sending...' : 'Approve'}
                    </button>
                  </div>
                </div>
              )}

              {/* Profile Sidebar (slides over) */}
              {showProfile && selectedLead && (
                <div className="profile-panel">
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div style={{ fontWeight: 600, fontSize: '.88rem' }}>Lead Profile</div>
                    <button onClick={() => setShowProfile(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--tx3)', fontSize: '1.1rem' }}>{'\u00D7'}</button>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px', padding: '12px 0', borderBottom: '1px solid var(--bdr)' }}>
                    <div style={{ width: '56px', height: '56px', borderRadius: '50%', background: 'var(--acc)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.4rem', fontWeight: 700, color: '#fff' }}>{getLeadName(selectedLead).charAt(0).toUpperCase()}</div>
                    {selectedLead.profile_name && <div style={{ fontWeight: 600, fontSize: '.9rem', textAlign: 'center', color: 'var(--tx)' }}>{selectedLead.profile_name}</div>}

                    {/* Editable username */}
                    {editingUsername ? (
                      <div style={{ display: 'flex', alignItems: 'center', gap: '6px', width: '100%' }}>
                        <input
                          value={usernameInput}
                          onChange={e => setUsernameInput(e.target.value)}
                          onKeyDown={e => { if (e.key === 'Enter') saveUsername(); if (e.key === 'Escape') setEditingUsername(false) }}
                          autoFocus
                          placeholder="Enter username..."
                          style={{ flex: 1, padding: '5px 8px', border: '1.5px solid var(--acc)', borderRadius: '8px', fontSize: '.8rem', fontFamily: 'var(--fn)', color: 'var(--tx)', background: 'var(--surf2)', outline: 'none' }}
                        />
                        <button onClick={saveUsername} style={{ padding: '5px 10px', background: 'var(--acc)', border: 'none', borderRadius: '8px', cursor: 'pointer', fontSize: '.75rem', color: '#fff', fontWeight: 600 }}>Save</button>
                        <button onClick={() => setEditingUsername(false)} style={{ padding: '5px 8px', background: 'var(--surf2)', border: '1px solid var(--bdr)', borderRadius: '8px', cursor: 'pointer', fontSize: '.75rem', color: 'var(--tx3)' }}>✕</button>
                      </div>
                    ) : (
                      <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                        <div style={{ fontSize: '.82rem', color: 'var(--tx3)', textAlign: 'center' }}>
                          {selectedLead.username ? `@${selectedLead.username}` : <span style={{ color: 'var(--tx3)', fontStyle: 'italic' }}>No username</span>}
                        </div>
                        <button onClick={() => { setUsernameInput(selectedLead.username || ''); setEditingUsername(true) }} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--tx3)', fontSize: '.72rem', padding: '2px 5px', borderRadius: '4px' }} title="Edit username">✏</button>
                      </div>
                    )}

                    {selectedLead.username && (selectedLead.channel === 'manychat' || (selectedLead.channel || '').toLowerCase().includes('instagram') || (selectedLead.channel || '').toLowerCase() === 'ig') && (
                      <a href={`https://www.instagram.com/${selectedLead.username.replace('@','')}`} target="_blank" rel="noopener noreferrer" style={{ fontSize: '.75rem', color: '#e1306c', fontWeight: 600, textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '4px', padding: '3px 10px', borderRadius: '999px', background: '#fff0f5', border: '1px solid #f9c0d0' }}>
                        <span>{'\uD83D\uDCF8'}</span> View Instagram
                      </a>
                    )}
                    {/* Lead ID — always visible so setter can identify leads without usernames */}
                    <div style={{ fontSize: '.68rem', color: 'var(--tx3)', background: 'var(--surf2)', border: '1px solid var(--bdr)', padding: '2px 8px', borderRadius: '999px', fontFamily: 'monospace' }}>ID: {selectedLead.customer_id}</div>
                  </div>
                  {[
                    { label: 'Lead Intent', value: selectedLead.lead_intent },
                    { label: 'Primary Goal', value: selectedLead.primary_goal },
                    { label: 'Stage', value: selectedLead.conversation_stage },
                    { label: 'Channel', value: selectedLead.channel },
                    { label: 'Last Interaction', value: selectedLead.last_activity ? timeAgo(selectedLead.last_activity) : '—' },
                    { label: 'Golf Identity', value: selectedLead.profile_facts?.golf_identity },
                    { label: 'Timeframe', value: selectedLead.profile_facts?.timeframe },
                    { label: "What They've Tried", value: selectedLead.profile_facts?.what_theyve_tried },
                    { label: 'Current Approach', value: selectedLead.profile_facts?.current_approach_working },
                    { label: 'Priority Level', value: selectedLead.profile_facts?.priority_level },
                  ].filter(f => f.value && f.value !== '').map(f => (
                    <div key={f.label}>
                      <div style={{ fontSize: '.67rem', fontWeight: 600, color: 'var(--tx3)', textTransform: 'uppercase', letterSpacing: '.06em', marginBottom: '3px' }}>{f.label}</div>
                      <div style={{ fontSize: '.81rem', color: 'var(--tx)', lineHeight: 1.5 }}>{f.value}</div>
                    </div>
                  ))}
                  {selectedLead.running_summary && (
                    <div style={{ borderTop: '1px solid var(--bdr)', paddingTop: '14px' }}>
                      <div style={{ fontSize: '.67rem', fontWeight: 600, color: 'var(--tx3)', textTransform: 'uppercase', letterSpacing: '.06em', marginBottom: '6px' }}>Summary</div>
                      <div style={{ fontSize: '.79rem', color: 'var(--tx2)', lineHeight: 1.6 }}>{selectedLead.running_summary}</div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </>
        )}
      </div>

      {/* ── TRAIN MODAL ── */}
      {showTrainModal && activeReview && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.5)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px' }}>
          <div style={{ background: 'var(--surf)', borderRadius: 'var(--rlg)', boxShadow: 'var(--shm)', width: '100%', maxWidth: '560px', overflow: 'hidden' }}>
            <div style={{ padding: '18px 20px', borderBottom: '1px solid var(--bdr)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div>
                <div style={{ fontWeight: 700, fontSize: '.95rem' }}>✏ Edit & Train</div>
                <div style={{ fontSize: '.75rem', color: 'var(--tx3)', marginTop: '2px' }}>The bot will learn from your correction</div>
              </div>
              <button onClick={() => setShowTrainModal(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '1.3rem', color: 'var(--tx3)', lineHeight: 1 }}>{'\u00D7'}</button>
            </div>
            <div style={{ padding: '18px 20px', display: 'flex', flexDirection: 'column', gap: '16px', maxHeight: '65vh', overflowY: 'auto' }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                <label style={{ fontSize: '.75rem', fontWeight: 600, color: 'var(--tx2)' }}>Reply ({replyMessages.length} message{replyMessages.length !== 1 ? 's' : ''})</label>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {replyMessages.map((msg, idx) => (
                    <div key={idx} style={{ position: 'relative' }}>
                      <textarea className="form-input" rows={2} value={msg} onChange={e => updateReplyMessage(idx, e.target.value)} style={{ borderRadius: '10px', paddingRight: '36px' }} placeholder={`Message ${idx + 1}...`} />
                      {replyMessages.length > 1 && <button onClick={() => removeReplyMessage(idx)} style={{ position: 'absolute', top: '8px', right: '8px', width: '22px', height: '22px', borderRadius: '50%', background: '#fed7d7', border: 'none', cursor: 'pointer', fontSize: '.7rem', color: '#e53e3e' }}>{'\u00D7'}</button>}
                    </div>
                  ))}
                  {replyMessages.length < 3 && <button onClick={addReplyMessage} style={{ alignSelf: 'flex-start', padding: '4px 12px', background: 'var(--surf2)', border: '1px dashed var(--bdr)', borderRadius: '8px', cursor: 'pointer', fontSize: '.75rem', color: 'var(--tx3)' }}>+ Add message</button>}
                </div>
              </div>
              <div style={{ background: 'var(--surf2)', borderRadius: '10px', padding: '14px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                <div><div style={{ fontSize: '.75rem', fontWeight: 700, color: 'var(--tx2)', textTransform: 'uppercase', letterSpacing: '.07em' }}>Tag Lead Stage and Intent</div></div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
                  <label style={{ fontSize: '.75rem', fontWeight: 600, color: 'var(--tx2)' }}>Conversation Stage</label>
                  <select value={correctedStage || ''} onChange={e => setCorrectedStage(e.target.value)} className="form-input" style={{ fontSize: '.8rem', padding: '6px 10px', borderRadius: '8px' }}>
                    {STAGES.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
                  <label style={{ fontSize: '.75rem', fontWeight: 600, color: 'var(--tx2)' }}>Lead Intent</label>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    {['LOW', 'MEDIUM', 'HIGH'].map(i => (
                      <button key={i} onClick={() => setCorrectedIntent(i)} style={{ flex: 1, padding: '7px', borderRadius: '8px', border: 'none', cursor: 'pointer', fontSize: '.78rem', fontWeight: 600, background: correctedIntent === i ? (i === 'HIGH' ? '#e53e3e' : i === 'MEDIUM' ? '#d97706' : '#6b7280') : 'var(--surf)', color: correctedIntent === i ? '#fff' : 'var(--tx3)', outline: correctedIntent === i ? 'none' : '1px solid var(--bdr)' }}>{i}</button>
                    ))}
                  </div>
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Why did you make these changes? <span style={{ color: '#e53e3e' }}>*</span></label>
                <textarea className="form-input" rows={3} placeholder="e.g. Bot classified this as GOAL LOCK but the lead already stated their goal." value={trainReason} onChange={e => setTrainReason(e.target.value)} style={{ borderRadius: '10px' }} />
                <div className="form-hint">The more detail you give, the faster the AI learns.</div>
              </div>
            </div>
            <div style={{ padding: '14px 20px', borderTop: '1px solid var(--bdr)', display: 'flex', gap: '8px', justifyContent: 'flex-end' }}>
              <button className="btn btn-ghost" onClick={() => setShowTrainModal(false)} style={{ borderRadius: '10px' }}>Cancel</button>
              <button onClick={saveTraining} disabled={sending || !trainReason.trim()} style={{ padding: '9px 20px', background: 'var(--acc)', border: 'none', borderRadius: '10px', cursor: 'pointer', fontSize: '.84rem', color: '#fff', fontWeight: 600, opacity: sending || !trainReason.trim() ? .6 : 1 }}>{sending ? 'Saving...' : 'Save & Train'}</button>
            </div>
          </div>
        </div>
      )}

      <style>{`
        .inbox-wrapper { display: flex; height: 100%; overflow: hidden; background: var(--bg); position: relative; }
        .inbox-list { width: 100%; flex-shrink: 0; border-right: 1px solid var(--bdr); flex-direction: column; background: var(--surf); min-height: 0; }
        .inbox-thread { flex: 1; flex-direction: column; overflow: hidden; background: var(--bg); min-width: 0; }
        .ai-panel { width: 340px; flex-shrink: 0; border-left: 1px solid var(--bdr); background: var(--surf); padding: 16px; display: flex; flex-direction: column; overflow: hidden; }
        .profile-panel { position: fixed; top: 0; right: 0; bottom: 0; width: min(85vw, 320px); z-index: 200; background: var(--surf); border-left: 1px solid var(--bdr); overflow-y: auto; padding: 20px 16px; display: flex; flex-direction: column; gap: 16px; box-shadow: -4px 0 24px rgba(0,0,0,.18); animation: slideInRight .2s ease; }
        .back-btn { background: var(--surf2); border: 1px solid var(--bdr); border-radius: 8px; cursor: pointer; font-size: 1rem; color: var(--tx2); padding: 6px 10px; display: flex; align-items: center; gap: 4px; transition: all .15s; }
        .back-btn:hover { background: var(--accl); color: var(--acc); }
        @keyframes slideInRight { from { transform: translateX(100%); } to { transform: translateX(0); } }
        @media (min-width: 1024px) {
          .inbox-list { width: 320px; }
          .profile-panel { position: relative; width: 280px; flex-shrink: 0; box-shadow: none; animation: none; }
        }
        @media (max-width: 1023px) {
          .ai-panel { position: fixed; top: 0; right: 0; bottom: 0; width: min(90vw, 360px); z-index: 200; box-shadow: -4px 0 24px rgba(0,0,0,.18); animation: slideInRight .2s ease; }
        }
        @media (min-width: 768px) {
          .inbox-thread { display: flex !important; }
        }
      `}</style>
    </div>
  )
}
